<div align="center">
  <p><img src="https://res.cloudinary.com/time2hack/image/upload/simple-login-in-firebase-web-api.png" alt="Simple Login in Firebase Web API" width="200" /></p>
  
[Simple Login in Firebase Web API](http://time2hack.com/2015/05/simple-login-in-firebase-web-api/)
</div>

# Contact Store
Contact Store app in Firebase and JS
